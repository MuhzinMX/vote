import AddParties from '@/components/AddParties';

const CreateParties = () => {
  return (
    <>
      <AddParties />
    </>
  );
};

export default CreateParties;

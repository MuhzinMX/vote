import HomePage from './HomePage';
import KulmiyePage from './KulmiyePage';
import WadaniPage from './WadaniPage';
import UcidPage from './UcidPage';
import Login from './Login';
import UsersPage from './UsersPage';

export { HomePage, KulmiyePage, WadaniPage, UcidPage, Login, UsersPage };

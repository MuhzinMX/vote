# GOBOLADA
  - Awdal id="path47640"
  - m/jeex id = "path47638"
  - Sahil id="path47630"
  - Togdheer id="path47636"
  - Sanaag  id="path47632"
  - Sool id="path47636"


# title
- id="title47594"